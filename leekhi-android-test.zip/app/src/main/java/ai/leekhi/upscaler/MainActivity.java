package ai.leekhi.upscaler;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;

/** Shell: loads the live site in a WebView, handles file picking and saving results to Downloads. */
public class MainActivity extends Activity {
    private static final String HOST = "leekhiplus.github.io";
    private static final String URL = "https://" + HOST + "/ZafRoniX-Ai/";
    private WebView web;
    private ValueCallback<Uri[]> chooser;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        // Keep the screen on: processing stops if the phone sleeps.
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "LeekhiAndroid");

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                if ("blob".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true; // never load other sites inside the app (the bridge must stay private to our site)
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                try { startActivityForResult(p.createIntent(), 1); }
                catch (Exception e) { chooser = null; return false; }
                return true;
            }
        });

        web.setDownloadListener((url, ua, contentDisposition, mime, length) -> {
            if (url != null && url.startsWith("blob:")) {
                String name = URLUtil.guessFileName(url, contentDisposition, mime);
                saveBlob(url, name, mime);
            } else {
                toast("This download type is not supported yet.");
            }
        });

        web.loadUrl(URL);
    }

    /** Reads a blob: URL in the page in 3 MB slices and sends it to the bridge. */
    private void saveBlob(String blobUrl, String name, String mime) {
        String js = "(function(){var u=" + quote(blobUrl) + ";fetch(u).then(function(r){return r.blob();}).then(function(b){"
            + "LeekhiAndroid.begin(" + quote(name) + "," + quote(mime == null || mime.isEmpty() ? "application/octet-stream" : mime) + ");"
            + "var size=b.size,off=0,step=3*1024*1024;"
            + "(function next(){if(off>=size){LeekhiAndroid.end();return;}"
            + "var fr=new FileReader();fr.onload=function(){var s=fr.result;LeekhiAndroid.chunk(s.substring(s.indexOf(',')+1));off+=step;next();};"
            + "fr.onerror=function(){LeekhiAndroid.fail('read error');};"
            + "fr.readAsDataURL(b.slice(off,off+step));})();"
            + "}).catch(function(e){LeekhiAndroid.fail(String(e));});})();";
        web.evaluateJavascript(js, null);
    }

    private static String quote(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ") + "\"";
    }

    private void toast(final String m) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show());
    }

    /** Called from the page (our own site only) to save a result into Downloads/Leekhi Ai. */
    private class Bridge {
        private OutputStream out;
        private Uri uri;

        @JavascriptInterface public synchronized void begin(String name, String mime) {
            try {
                String safe = name.replaceAll("[\\\\/:*?\"<>|]", "_");
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                cv.put(MediaStore.Downloads.MIME_TYPE, mime);
                cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Leekhi Ai");
                cv.put(MediaStore.Downloads.IS_PENDING, 1);
                ContentResolver r = getContentResolver();
                uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                out = uri == null ? null : r.openOutputStream(uri);
                if (out == null) toast("Could not create the file.");
            } catch (Exception e) {
                out = null;
                toast("Save failed: " + e.getMessage());
            }
        }

        @JavascriptInterface public synchronized void chunk(String b64) {
            try { if (out != null) out.write(Base64.decode(b64, Base64.DEFAULT)); }
            catch (Exception e) { fail(String.valueOf(e.getMessage())); }
        }

        @JavascriptInterface public synchronized void end() {
            try {
                if (out == null) return;
                out.close();
                out = null;
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, cv, null, null);
                toast("Saved to Downloads/Leekhi Ai");
            } catch (Exception e) {
                toast("Save failed: " + e.getMessage());
            }
        }

        @JavascriptInterface public synchronized void fail(String why) {
            try { if (out != null) out.close(); } catch (Exception ignored) { }
            try { if (uri != null) getContentResolver().delete(uri, null, null); } catch (Exception ignored) { }
            out = null;
            toast("Save failed: " + why);
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == 1 && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            chooser = null;
        }
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
